#ifndef OS_INCLUDE_CONSOLE_H
#define OS_INCLUDE_CONSOLE_H

void new_line();
void tab();
void clear_terminal();
void print_character(char c);
void print_string(char* str);
void print_line(char* str);

#endif
